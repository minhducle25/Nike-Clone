import React from 'react'

const NavMain = () => {
  return (
    <div>NavMain</div>
  )
}

export default NavMain