import React from 'react'
import Cart from '../../components/Body/Cart/cart'

const CartPage = () => {
  return (
    <React.Fragment>
        <Cart/>
    </React.Fragment>
  )
}
export default CartPage