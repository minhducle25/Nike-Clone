import React from 'react'
import UserOrders from "../../components/User/userOrder/userOrder"

const UserOrder = () => {
  return (
    <React.Fragment>
        <UserOrders/>
    </React.Fragment>
  )
}

export default UserOrder